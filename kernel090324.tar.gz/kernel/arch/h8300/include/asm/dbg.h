#define DEBUG 1
#define	BREAK asm volatile ("trap #3")
