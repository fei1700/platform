#ifndef _H8300_STATFS_H
#define _H8300_STATFS_H

#include <asm-generic/statfs.h>

#endif /* _H8300_STATFS_H */
