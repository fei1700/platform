#ifndef _H8300_SIGINFO_H
#define _H8300_SIGINFO_H

#include <asm-generic/siginfo.h>

#endif
