#ifndef __H8300_SPINLOCK_H
#define __H8300_SPINLOCK_H

#error "H8/300 doesn't do SMP yet"

#endif
