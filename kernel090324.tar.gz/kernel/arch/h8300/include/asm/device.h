/*
 * Arch specific extensions to struct device
 *
 * This file is released under the GPLv2
 */
#include <asm-generic/device.h>

