/*
 * Machine dependent access functions for RTC registers.
 */
#ifndef _H8300_MC146818RTC_H
#define _H8300_MC146818RTC_H

/* empty include file to satisfy the include in genrtc.c/ide-geometry.c */

#endif /* _H8300_MC146818RTC_H */
