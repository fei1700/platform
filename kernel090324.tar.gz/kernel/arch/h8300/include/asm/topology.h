#ifndef _ASM_H8300_TOPOLOGY_H
#define _ASM_H8300_TOPOLOGY_H

#include <asm-generic/topology.h>

#endif /* _ASM_H8300_TOPOLOGY_H */
