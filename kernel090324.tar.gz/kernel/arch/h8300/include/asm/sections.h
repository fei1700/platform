#ifndef _H8300_SECTIONS_H_
#define _H8300_SECTIONS_H_

#include <asm-generic/sections.h>

#endif
