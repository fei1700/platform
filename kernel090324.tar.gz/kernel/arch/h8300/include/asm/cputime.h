#ifndef __H8300_CPUTIME_H
#define __H8300_CPUTIME_H

#include <asm-generic/cputime.h>

#endif /* __H8300_CPUTIME_H */
