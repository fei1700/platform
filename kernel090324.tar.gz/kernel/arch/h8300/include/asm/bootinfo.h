
/* Nothing for h8300 */
