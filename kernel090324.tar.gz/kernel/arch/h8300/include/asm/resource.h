#ifndef _H8300_RESOURCE_H
#define _H8300_RESOURCE_H

#include <asm-generic/resource.h>

#endif /* _H8300_RESOURCE_H */
