#ifndef __ARCH_H8300_PERCPU__
#define __ARCH_H8300_PERCPU__

#include <asm-generic/percpu.h>

#endif /* __ARCH_H8300_PERCPU__ */
