#ifndef _H8300_ERRNO_H
#define _H8300_ERRNO_H

#include <asm-generic/errno.h>

#endif /* _H8300_ERRNO_H */
