#ifndef _H8300_LOCAL_H_
#define _H8300_LOCAL_H_

#include <asm-generic/local.h>

#endif
