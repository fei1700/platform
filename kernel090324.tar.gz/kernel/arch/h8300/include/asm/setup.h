#ifndef __H8300_SETUP_H
#define __H8300_SETUP_H

#define COMMAND_LINE_SIZE	512

#endif
