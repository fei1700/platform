#ifndef _H8300_PGALLOC_H
#define _H8300_PGALLOC_H

#include <asm/setup.h>

#define check_pgt_cache()	do { } while (0)

#endif /* _H8300_PGALLOC_H */
