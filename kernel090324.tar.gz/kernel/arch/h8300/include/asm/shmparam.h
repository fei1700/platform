#ifndef _H8300_SHMPARAM_H
#define _H8300_SHMPARAM_H

#define	SHMLBA PAGE_SIZE		 /* attach addr a multiple of this */

#endif /* _H8300_SHMPARAM_H */
