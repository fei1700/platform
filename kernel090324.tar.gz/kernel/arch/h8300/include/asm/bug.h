#ifndef _H8300_BUG_H
#define _H8300_BUG_H
#include <asm-generic/bug.h>
#endif
