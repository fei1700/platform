#ifndef __ASMH8300_AUXVEC_H
#define __ASMH8300_AUXVEC_H

#endif
