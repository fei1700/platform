#ifndef __ALPHA_SUSPEND_H
#define __ALPHA_SUSPEND_H

/* Dummy include. */

#endif  /* __ALPHA_SUSPEND_H */
