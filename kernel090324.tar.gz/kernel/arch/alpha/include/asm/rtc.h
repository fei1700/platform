#ifndef _ALPHA_RTC_H
#define _ALPHA_RTC_H

/*
 * Alpha uses the default access methods for the RTC.
 */

#include <asm-generic/rtc.h>

#endif
