#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x6d2877cc, "struct_module" },
	{ 0xd65ca4fc, "crypto_unregister_template" },
	{ 0x65ad6015, "crypto_register_template" },
	{ 0x5d1b3af0, "crypto_hash_type" },
	{ 0x379365b2, "crypto_aead_type" },
	{ 0x77bf8cb, "malloc_sizes" },
	{ 0x37a0cba, "kfree" },
	{ 0x9cfb0055, "crypto_drop_spawn" },
	{ 0xc5792544, "crypto_mod_put" },
	{ 0x701d0ebd, "snprintf" },
	{ 0x963ad9b6, "crypto_grab_skcipher" },
	{ 0x76f843c7, "crypto_init_spawn" },
	{ 0xdc74cc24, "kmem_cache_alloc" },
	{ 0x9a11a0fc, "crypto_attr_alg_name" },
	{ 0x54d09e69, "crypto_attr_alg" },
	{ 0x124f2056, "crypto_get_attr_type" },
	{ 0x1d84e9c1, "crypto_free_tfm" },
	{ 0xcd88d7ac, "crypto_spawn_tfm" },
	{ 0x71c90087, "memcmp" },
	{ 0x9d669763, "memcpy" },
	{ 0x2b3b9059, "mem_map" },
	{ 0xf807fd65, "scatterwalk_map_and_copy" },
	{ 0x6898a756, "sg_init_table" },
	{ 0x799aca4, "local_bh_enable" },
	{ 0x3ff62317, "local_bh_disable" },
	{ 0xc27487dd, "__bug" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=crypto_hash,aead";


MODULE_INFO(srcversion, "AAA1340568939BC3D096D69");
