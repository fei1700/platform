#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x6d2877cc, "struct_module" },
	{ 0xd65ca4fc, "crypto_unregister_template" },
	{ 0x65ad6015, "crypto_register_template" },
	{ 0x37a0cba, "kfree" },
	{ 0x9cfb0055, "crypto_drop_spawn" },
	{ 0xd02c0600, "crypto_blkcipher_type" },
	{ 0xc5792544, "crypto_mod_put" },
	{ 0x467373b9, "crypto_alloc_instance" },
	{ 0x54d09e69, "crypto_attr_alg" },
	{ 0xd16712f3, "crypto_check_attr_type" },
	{ 0x1d84e9c1, "crypto_free_tfm" },
	{ 0xcd88d7ac, "crypto_spawn_tfm" },
	{ 0xb83a968a, "blkcipher_walk_done" },
	{ 0x30248a95, "blkcipher_walk_virt" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "5BBA8E5CDEA4EA8BA5ED31D");
